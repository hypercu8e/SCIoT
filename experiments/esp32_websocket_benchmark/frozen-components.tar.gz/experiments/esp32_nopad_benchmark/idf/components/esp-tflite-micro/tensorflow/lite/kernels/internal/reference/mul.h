/* Copyright 2023 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#ifndef TENSORFLOW_LITE_KERNELS_INTERNAL_REFERENCE_MUL_H_
#define TENSORFLOW_LITE_KERNELS_INTERNAL_REFERENCE_MUL_H_

#include <algorithm>
#include <complex>

#include "tensorflow/lite/kernels/internal/common.h"
#include "tensorflow/lite/kernels/internal/reference/broadcast_loop.h"

namespace tflite {

namespace reference_ops {

// Maximum dimension supported by the broadcast mul operation.
constexpr int kMaxMulBroadcastDim = 6;

// Element-wise mul that can often be used for inner loop of broadcast Mul as
// well as the non-broadcast Mul.
inline void MulElementwise(int size, const ArithmeticParams& params,
                           const uint8_t* input1_data,
                           const uint8_t* input2_data, uint8_t* output_data) {
  for (int i = 0; i < size; ++i) {
    const int32_t input1_val = params.input1_offset + input1_data[i];
    const int32_t input2_val = params.input2_offset + input2_data[i];
    const int32_t unclamped_result =
        params.output_offset +
        MultiplyByQuantizedMultiplier(input1_val * input2_val,
                                      params.output_multiplier,
                                      params.output_shift);
    const int32_t clamped_output =
        std::min(params.quantized_activation_max,
                 std::max(params.quantized_activation_min, unclamped_result));
    output_data[i] = static_cast<uint8_t>(clamped_output);
  }
}

template <typename T>
inline void Mul(const ArithmeticParams& params,
                const RuntimeShape& input1_shape, const T* input1_data,
                const RuntimeShape& input2_shape, const T* input2_data,
                const RuntimeShape& output_shape, T* output_data) {
  T output_activation_min;
  T output_activation_max;
  GetActivationParams(params, &output_activation_min, &output_activation_max);

  const int flat_size =
      MatchingExtendedShapeFlatSize(input1_shape, input2_shape, output_shape);
  for (int i = 0; i < flat_size; ++i) {
    output_data[i] = ActivationFunctionWithMinMax<T>(
        WrappingMul<T>(input1_data[i], input2_data[i]), output_activation_min,
        output_activation_max);
  }
}

inline void Mul(const ArithmeticParams& params,
                const RuntimeShape& input1_shape,
                const std::complex<float>* input1_data,
                const RuntimeShape& input2_shape,
                const std::complex<float>* input2_data,
                const RuntimeShape& output_shape,
                std::complex<float>* output_data) {
  const int flat_size =
      MatchingExtendedShapeFlatSize(input1_shape, input2_shape, output_shape);
  for (int i = 0; i < flat_size; ++i) {
    output_data[i] = input1_data[i] * input2_data[i];
  }
}

inline void Mul(const ArithmeticParams& params,
                const RuntimeShape& input1_shape, const uint8_t* input1_data,
                const RuntimeShape& input2_shape, const uint8_t* input2_data,
                const RuntimeShape& output_shape, uint8_t* output_data) {
  TFLITE_DCHECK_LE(params.quantized_activation_min,
                   params.quantized_activation_max);
  const int flat_size =
      MatchingExtendedShapeFlatSize(input1_shape, input2_shape, output_shape);

  MulElementwise(flat_size, params, input1_data, input2_data, output_data);
}

inline void BroadcastMul6DSlow(const ArithmeticParams& params,
                               const RuntimeShape& input1_shape,
                               const uint8_t* input1_data,
                               const RuntimeShape& input2_shape,
                               const uint8_t* input2_data,
                               const RuntimeShape& output_shape,
                               uint8_t* output_data) {
  auto op = [&params](uint8_t input1_val, uint8_t input2_val) {
    const int32_t offsetted_input1_val = params.input1_offset + input1_val;
    const int32_t offsetted_input2_val = params.input2_offset + input2_val;
    const int32_t unclamped_result =
        params.output_offset + MultiplyByQuantizedMultiplier(
                                   offsetted_input1_val * offsetted_input2_val,
                                   params.output_multiplier,
                                   params.output_shift);
    const int32_t clamped_output =
        std::min(params.quantized_activation_max,
                 std::max(params.quantized_activation_min, unclamped_result));
    return static_cast<uint8_t>(clamped_output);
  };
  BroadcastBinaryOpSimple(input1_shape, input1_data, input2_shape, input2_data,
                          output_shape, output_data, op);
}

template <typename T,
          // For unquantized mul on small integers, explicitly set to true.
          bool enable_for_short_integers = false>
inline typename std::enable_if<
    !is_small_integer<T>::value || enable_for_short_integers, void>::type
BroadcastMul6DSlow(const ArithmeticParams& params,
                   const RuntimeShape& unextended_input1_shape,
                   const T* input1_data,
                   const RuntimeShape& unextended_input2_shape,
                   const T* input2_data,
                   const RuntimeShape& unextended_output_shape,
                   T* output_data) {
  T output_activation_min;
  T output_activation_max;
  GetActivationParams(params, &output_activation_min, &output_activation_max);
  auto op = [output_activation_min, output_activation_max](T a, T b) {
    return ActivationFunctionWithMinMax<T>(
        WrappingMul<T>(a, b), output_activation_min, output_activation_max);
  };
  BroadcastBinaryOpSimple(unextended_input1_shape, input1_data,
                          unextended_input2_shape, input2_data,
                          unextended_output_shape, output_data, op);
}

inline void BroadcastMul6DSlow(const ArithmeticParams& params,
                               const RuntimeShape& unextended_input1_shape,
                               const std::complex<float>* input1_data,
                               const RuntimeShape& unextended_input2_shape,
                               const std::complex<float>* input2_data,
                               const RuntimeShape& unextended_output_shape,
                               std::complex<float>* output_data) {
  auto op = [](std::complex<float> a, std::complex<float> b) { return a * b; };
  BroadcastBinaryOpSimple(unextended_input1_shape, input1_data,
                          unextended_input2_shape, input2_data,
                          unextended_output_shape, output_data, op);
}

template <typename T>
inline void BroadcastMul4DSlow(
    const ArithmeticParams& params, const RuntimeShape& input1_shape,
    const T* input1_data, const RuntimeShape& input2_shape,
    const T* input2_data, const RuntimeShape& output_shape, T* output_data) {
  return BroadcastMul6DSlow(params, input1_shape, input1_data, input2_shape,
                            input2_data, output_shape, output_data);
}

}  // namespace reference_ops
}  // namespace tflite

#endif  // TENSORFLOW_LITE_KERNELS_INTERNAL_REFERENCE_MUL_H_
