cmake_minimum_required(VERSION 3.5)

set(c_srcs
    "src/activation_functions/esp_nn_relu_ansi.c"
    "src/activation_functions/esp_nn_hard_swish_ansi.c"
    "src/common/esp_nn_mean_ansi.c"
    "src/basic_math/esp_nn_add_ansi.c"
    "src/basic_math/esp_nn_mul_ansi.c"
    "src/convolution/esp_nn_conv_ansi.c"
    "src/convolution/esp_nn_conv_opt.c"
    "src/convolution/esp_nn_depthwise_conv_ansi.c"
    "src/convolution/esp_nn_depthwise_conv_opt.c"
    "src/fully_connected/esp_nn_fully_connected_ansi.c"
    "src/softmax/esp_nn_softmax_ansi.c"
    "src/softmax/esp_nn_softmax_opt.c"
    "src/logistic/esp_nn_logistic_ansi.c"
    "src/pooling/esp_nn_avg_pool_ansi.c"
    "src/pooling/esp_nn_max_pool_ansi.c"
    "src/common/esp_nn_multicore.c"
    "src/convolution/esp_nn_conv_mt_split.c"
    "src/basic_math/esp_nn_mul_mt.c")

if(CONFIG_IDF_TARGET_ESP32S3)
    set(s3_srcs
        "src/common/esp_nn_common_functions_esp32s3.S"
        "src/common/esp_nn_dot_s8_esp32s3.S"
        "src/common/esp_nn_multiply_by_quantized_mult_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s8_kx1_esp32s3.S"
        "src/common/esp_nn_multiply_by_quantized_mult_ver1_esp32s3.S"
        "src/activation_functions/esp_nn_relu_s8_esp32s3.S"
        "src/activation_functions/esp_nn_hard_swish_s8_esp32s3.c"
        "src/common/esp_nn_mean_s8_esp32s3.c"
        "src/basic_math/esp_nn_add_s8_esp32s3.S"
        "src/basic_math/esp_nn_add_mt_esp32s3.c"
        "src/basic_math/esp_nn_mul_s8_esp32s3.S"
        "src/basic_math/esp_nn_mul_broadcast_s8_esp32s3.S"
        "src/convolution/esp_nn_conv_esp32s3.c"
        "src/convolution/esp_nn_conv_s8_1x1_esp32s3.c"
        "src/convolution/esp_nn_conv_s8_3x3_opt_esp32s3.c"
        "src/convolution/esp_nn_depthwise_conv_s8_esp32s3.c"
        "src/convolution/esp_nn_conv_s16_mult8_esp32s3.S"
        "src/convolution/esp_nn_conv_s8_mult8_1x1_esp32s3.S"
        "src/convolution/esp_nn_conv_s16_mult4_1x1_esp32s3.S"
        "src/convolution/esp_nn_conv_s8_filter_aligned_input_padded_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s8_mult1_3x3_padded_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult1_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult1_3x3_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult1_3x3_no_pad_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult8_3x3_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult4_esp32s3.S"
        "src/convolution/esp_nn_depthwise_conv_s16_mult8_esp32s3.S"
        "src/fully_connected/esp_nn_fully_connected_esp32s3.c"
        "src/fully_connected/esp_nn_fc_s8_mac16_esp32s3.S"
        "src/fully_connected/esp_nn_fully_connected_s8_esp32s3.S"
        "src/fully_connected/esp_nn_fully_connected_per_ch_s8_esp32s3.S"
        "src/pooling/esp_nn_max_pool_s8_esp32s3.S"
        "src/pooling/esp_nn_avg_pool_s8_esp32s3.c"
        "src/pooling/esp_nn_avg_pool_s8_esp32s3.S"
        "src/softmax/esp_nn_softmax_s8_esp32s3.c")
endif()

# ESP32-S31 shares the P4 PIE/SIMD ISA, so it reuses the ESP32-P4 kernels
if(CONFIG_IDF_TARGET_ESP32P4 OR CONFIG_IDF_TARGET_ESP32S31)
    set(riscv_pie_srcs
        "src/common/esp_nn_mean_s8_riscv_pie.c"
        "src/common/esp_nn_multiply_by_quantized_mult_riscv_pie.S"
        "src/activation_functions/esp_nn_hard_swish_s8_riscv_pie.c"
        "src/activation_functions/esp_nn_relu_s8_riscv_pie.c"
        "src/basic_math/esp_nn_add_s8_riscv_pie.c"
        "src/basic_math/esp_nn_mul_s8_riscv_pie.c"
        "src/convolution/esp_nn_conv_riscv_pie.c"
        "src/convolution/esp_nn_depthwise_conv_riscv_pie.c"
        "src/fully_connected/esp_nn_fully_connected_s8_riscv_pie.c"
        "src/pooling/esp_nn_avg_pool_s8_riscv_pie.c"
        "src/pooling/esp_nn_max_pool_s8_riscv_pie.c"
        "src/softmax/esp_nn_softmax_s8_riscv_pie.c")
endif()

idf_component_register(SRCS "${c_srcs}"
                            "${s3_srcs}"
                            "${riscv_pie_srcs}"
                       INCLUDE_DIRS "include" "src/common")

if(CONFIG_IDF_TARGET_ESP32S3)
    target_compile_options(${COMPONENT_LIB} PRIVATE -mlongcalls -fno-unroll-loops -O2 -Wno-unused-function)
else()
    target_compile_options(${COMPONENT_LIB} PRIVATE  -O2 -Wno-unused-function)
endif()

if(CONFIG_NN_SKIP_NUDGE)
    target_compile_definitions(${COMPONENT_LIB} PRIVATE SKIP_NUDGE)
endif()
