/*
 * SPDX-FileCopyrightText: 2020-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @file        Header definitions to include for esp_nn optimized functions for
 *              the ESP32-S3 platform
 */

#pragma once

#include <stddef.h>

#include "esp_nn_defs.h"
#include "esp_nn_ansi_headers.h"

/************************** Basic math functions *****************************/


/**
 * @brief       elementwise addition
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 *
 *              shift values are expected to be <= 0
 */
void esp_nn_add_elementwise_s8_mt_esp32s3(const int8_t *input1_data,
                                          const int8_t *input2_data,
                                          const int32_t input1_offset,
                                          const int32_t input2_offset,
                                          const int32_t input1_mult,
                                          const int32_t input2_mult,
                                          const int32_t input1_shift,
                                          const int32_t input2_shift,
                                          const int32_t left_shift,
                                          int8_t *output,
                                          const int32_t out_offset,
                                          const int32_t out_mult,
                                          const int32_t out_shift,
                                          const int32_t activation_min,
                                          const int32_t activation_max,
                                          const int32_t size);

void esp_nn_add_elementwise_s8_esp32s3(const int8_t *input1_data,
                                       const int8_t *input2_data,
                                       const int32_t input1_offset,
                                       const int32_t input2_offset,
                                       const int32_t input1_mult,
                                       const int32_t input2_mult,
                                       const int32_t input1_shift,
                                       const int32_t input2_shift,
                                       const int32_t left_shift,
                                       int8_t *output,
                                       const int32_t out_offset,
                                       const int32_t out_mult,
                                       const int32_t out_shift,
                                       const int32_t activation_min,
                                       const int32_t activation_max,
                                       const int32_t size);

/**
 * @brief       elementwise multiplication
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 *
 *              output shift is expected to be <= 0
 */
void esp_nn_mul_elementwise_s8_esp32s3(const int8_t *input1_data,
                                       const int8_t *input2_data,
                                       const int32_t input1_offset,
                                       const int32_t input2_offset,
                                       int8_t *output,
                                       const int32_t out_offset,
                                       const int32_t out_mult,
                                       const int32_t out_shift,
                                       const int32_t activation_min,
                                       const int32_t activation_max,
                                       const int32_t size);


/************************** Convolution functions *****************************/

/**
 * @brief       depthwise convolution per channel
 *
 * @note        inputs type: int8_t, output: int8_t
 *              Version used in tflite is per channel.
 *              This version follows the same footsprints.
 *              Meaning, it has per out_channel shift and multiplier for
 *              requantization
 *
 *              optimization notes: Though input_offset is int32 type,
 *              offset values are contained in 8 bits [-128, 127]
 */
void esp_nn_depthwise_conv_s8_esp32s3(const data_dims_t *input_dims,
                                      const int8_t *input_data,
                                      const data_dims_t *filter_dims,
                                      const int8_t *filter_data,
                                      const int32_t *bias,
                                      const data_dims_t *output_dims,
                                      int8_t *output_data,
                                      const dw_conv_params_t *conv_params,
                                      const quant_data_t *quant_data);

/**
 * @brief       2d - convolution channelwise
 *
 * @note        operation: result += (input + offset) * filter
 *
 *              inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 */
void esp_nn_conv_s8_esp32s3(const data_dims_t *input_dims,
                            const int8_t *input_data,
                            const data_dims_t *filter_dims,
                            const int8_t *filter_data,
                            const int32_t *bias,
                            const data_dims_t *output_dims,
                            int8_t *output_data,
                            const conv_params_t *conv_params,
                            const quant_data_t *quant_data);

int esp_nn_get_conv_scratch_size_esp32s3(const data_dims_t *input_dims,
                                         const data_dims_t *filter_dims,
                                         const data_dims_t *output_dims,
                                         const conv_params_t *conv_params);
void esp_nn_set_conv_scratch_buf_esp32s3(const void *buf);

/**
 * @brief       Prefer a caller-owned buffer for convolution workspace
 *
 * @note        The buffer must remain valid until it is replaced or cleared
 *              with (NULL, 0). The buffer must be 16-byte aligned. If it is
 *              unaligned or too small for an operation, the ordinary scratch
 *              buffer remains in use.
 */
void esp_nn_set_conv_preferred_scratch_buf_esp32s3(void *buf, size_t size);

int esp_nn_get_depthwise_conv_scratch_size_esp32s3(const data_dims_t *input_dims,
                                                   const data_dims_t *filter_dims,
                                                   const data_dims_t *output_dims,
                                                   const dw_conv_params_t *conv_params);
void esp_nn_set_depthwise_conv_scratch_buf_esp32s3(const void *buf);

/**
 * @brief       Prefer a caller-owned buffer for depthwise workspace
 *
 * @note        The buffer must remain valid until it is replaced or cleared
 *              with (NULL, 0). The buffer must be 16-byte aligned. If it is
 *              unaligned or too small for an operation, the ordinary scratch
 *              buffer remains in use.
 */
void esp_nn_set_depthwise_conv_preferred_scratch_buf_esp32s3(void *buf,
                                                             size_t size);

/************************** Pooling functions *****************************/

/**
 * @brief       max_pool
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 */
void esp_nn_max_pool_s8_esp32s3(const int8_t *input,
                                const uint16_t input_wd,
                                const uint16_t input_ht,
                                int8_t *output,
                                const uint16_t output_wd,
                                const uint16_t output_ht,
                                const uint16_t stride_wd,
                                const uint16_t stride_ht,
                                const uint16_t filter_wd,
                                const uint16_t filter_ht,
                                const uint16_t pad_wd,
                                const uint16_t pad_ht,
                                const int32_t activation_min,
                                const int32_t activation_max,
                                const uint16_t channels);

/**
 * @brief       avg_pool
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 */
void esp_nn_avg_pool_s8_esp32s3(const int8_t *input,
                                const uint16_t input_wd,
                                const uint16_t input_ht,
                                int8_t *output,
                                const uint16_t output_wd,
                                const uint16_t output_ht,
                                const uint16_t stride_wd,
                                const uint16_t stride_ht,
                                const uint16_t filter_wd,
                                const uint16_t filter_ht,
                                const uint16_t pad_wd,
                                const uint16_t pad_ht,
                                const int32_t activation_min,
                                const int32_t activation_max,
                                const uint16_t channels);


/************************** Fully connected functions *****************************/

/**
 * @brief       fully connected
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 *
 *              Any row_len and out_channels are accepted, and input_data and
 *              filter_data may be arbitrarily aligned. Alignment and remainders
 *              only select which internal path runs, not whether the result is
 *              correct.
 */
void esp_nn_fully_connected_s8_esp32s3(const int8_t *input_data,
                                       const int32_t input_offset,
                                       const uint16_t row_len,
                                       const int8_t *filter_data,
                                       const int32_t filter_offset,
                                       const int32_t *bias,
                                       int8_t *out_data,
                                       const uint16_t out_channels,
                                       const int32_t out_offset,
                                       const int32_t out_shift,
                                       const int32_t out_mult,
                                       const int32_t activation_min,
                                       const int32_t activation_max);

/**
 * @brief       fully connected - per channel
 *
 * @note        inputs type: int8_t, output: int8_t
 *              input offsets: although int32_t, they are contained in 8 bits [-128, 127]
 *              out_mult, out_shift: int32_t* containing per-channel data
 *
 *              Any row_len and out_channels are accepted, and input_data and
 *              filter_data may be arbitrarily aligned. Alignment and remainders
 *              only select which internal path runs, not whether the result is
 *              correct.
 */
void esp_nn_fully_connected_per_ch_s8_esp32s3(const int8_t *input_data,
                                       const int32_t input_offset,
                                       const uint16_t row_len,
                                       const int8_t *filter_data,
                                       const int32_t filter_offset,
                                       const int32_t *bias,
                                       int8_t *out_data,
                                       const uint16_t out_channels,
                                       const int32_t out_offset,
                                       const int32_t* out_shift,
                                       const int32_t* out_mult,
                                       const int32_t activation_min,
                                       const int32_t activation_max);

/**
 * @brief       relu6
 *
 * @note        inout: int8_t
 */
void esp_nn_relu6_s8_esp32s3(int8_t *data, uint16_t size);

/********************** function defines ***************************/

#define esp_nn_add_elementwise_s8 esp_nn_add_elementwise_s8_mt_esp32s3
void esp_nn_mul_elementwise_s8_mt(const int8_t *input1_data,
                                  const int8_t *input2_data,
                                  const int32_t input1_offset,
                                  const int32_t input2_offset,
                                  int8_t *output,
                                  const int32_t out_offset,
                                  const int32_t out_mult,
                                  const int32_t out_shift,
                                  const int32_t activation_min,
                                  const int32_t activation_max,
                                  const int32_t size);
#define esp_nn_mul_elementwise_s8 esp_nn_mul_elementwise_s8_mt

void esp_nn_mul_broadcast_channel_s8_esp32s3(const int8_t *input1,
                                              const int8_t *input2_per_ch,
                                              const int32_t input1_offset,
                                              const int32_t input2_offset,
                                              int8_t *output,
                                              const int32_t output_offset,
                                              const int32_t output_mult,
                                              const int32_t output_shift,
                                              const int32_t activation_min,
                                              const int32_t activation_max,
                                              const int32_t total_spatial,
                                              const int32_t channels);
#define esp_nn_mul_broadcast_channel_s8 esp_nn_mul_broadcast_channel_s8_esp32s3

#define esp_nn_depthwise_conv_s8 esp_nn_depthwise_conv_s8_esp32s3

#define esp_nn_get_conv_scratch_size esp_nn_get_conv_scratch_size_esp32s3
#define esp_nn_set_conv_scratch_buf esp_nn_set_conv_scratch_buf_esp32s3

#define esp_nn_get_depthwise_conv_scratch_size esp_nn_get_depthwise_conv_scratch_size_esp32s3
#define esp_nn_set_depthwise_conv_scratch_buf esp_nn_set_depthwise_conv_scratch_buf_esp32s3

#define esp_nn_conv_s8 esp_nn_conv_s8_esp32s3

#define esp_nn_relu6_s8 esp_nn_relu6_s8_esp32s3

int32_t esp_nn_get_hard_swish_scratch_size_esp32s3(void);
void esp_nn_set_hard_swish_scratch_buf_esp32s3(void *buf);
void esp_nn_hard_swish_s8_esp32s3(const int8_t *input, int8_t *output,
                                   const int32_t size,
                                   const int16_t input_zero_point,
                                   const int16_t output_mult_fxp,
                                   const int16_t reluish_mult_fxp,
                                   const int32_t reluish_mult_exp,
                                   const int32_t output_mult_exp,
                                   const int16_t output_zero_point);
#define esp_nn_get_hard_swish_scratch_size esp_nn_get_hard_swish_scratch_size_esp32s3
#define esp_nn_set_hard_swish_scratch_buf esp_nn_set_hard_swish_scratch_buf_esp32s3
#define esp_nn_hard_swish_s8 esp_nn_hard_swish_s8_esp32s3

void esp_nn_mean_nhwc_s8_esp32s3(const int8_t *input, int8_t *output,
                                  const int32_t height, const int32_t width,
                                  const int32_t channels,
                                  const int32_t input_zero_point,
                                  const int32_t output_zero_point,
                                  const int32_t multiplier,
                                  const int32_t shift);
int32_t esp_nn_get_mean_scratch_size_esp32s3(const int32_t height, const int32_t width,
                                             const int32_t channels);
void esp_nn_set_mean_scratch_buf_esp32s3(void *buffer);
#define esp_nn_mean_nhwc_s8 esp_nn_mean_nhwc_s8_esp32s3
#define esp_nn_get_mean_scratch_size esp_nn_get_mean_scratch_size_esp32s3
#define esp_nn_set_mean_scratch_buf esp_nn_set_mean_scratch_buf_esp32s3

#define esp_nn_avg_pool_s8 esp_nn_avg_pool_s8_esp32s3
#define esp_nn_max_pool_s8 esp_nn_max_pool_s8_esp32s3

void esp_nn_fully_connected_per_ch_s8_batch_esp32s3(const int8_t *input_data,
                                       const int32_t input_offset,
                                       const uint16_t row_len,
                                       const int8_t *filter_data,
                                       const int32_t filter_offset,
                                       const int32_t *bias,
                                       int8_t *out_data,
                                       const uint16_t out_channels,
                                       const int32_t out_offset,
                                       const int32_t *out_shift,
                                       const int32_t *out_mult,
                                       const int32_t activation_min,
                                       const int32_t activation_max,
                                       const int32_t batches);

#define esp_nn_fully_connected_s8 esp_nn_fully_connected_s8_esp32s3
#define esp_nn_fully_connected_per_ch_s8 esp_nn_fully_connected_per_ch_s8_esp32s3
#define esp_nn_fully_connected_per_ch_s8_batch esp_nn_fully_connected_per_ch_s8_batch_esp32s3

int32_t esp_nn_get_softmax_scratch_size_esp32s3(const int32_t width, const int32_t height);
void esp_nn_set_softmax_scratch_buf_esp32s3(void *buffer);
void esp_nn_softmax_s8_esp32s3(const int8_t *input_data, const int32_t height,
                                const int32_t width, const int32_t mult,
                                const int32_t shift, const int32_t diff_min,
                                int8_t *output_data);

#define esp_nn_get_softmax_scratch_size esp_nn_get_softmax_scratch_size_esp32s3
#define esp_nn_set_softmax_scratch_buf esp_nn_set_softmax_scratch_buf_esp32s3
#define esp_nn_softmax_s8 esp_nn_softmax_s8_esp32s3

/* Logistic (sigmoid) — LUT-based, same impl for all targets */
#define esp_nn_get_logistic_s8_scratch_size esp_nn_get_logistic_s8_scratch_size_ansi
#define esp_nn_logistic_s8_prepare esp_nn_logistic_s8_prepare_ansi
#define esp_nn_logistic_s8 esp_nn_logistic_s8_ansi
